import greenfoot.*;

public class Avanzar implements Estado {

    @Override
    public Estado actuar(Enemigo enemigo) {
        // Mueve el asteroide 3 píxeles hacia la izquierda en línea recta
        enemigo.setLocation(enemigo.getX() - 3, enemigo.getY());
        return this; // Mantiene el estado de avance sin cambiar a zigzag
    }
}
import greenfoot.*;

public class Nave extends Actor {

    private EstrategiaDisparo estrategia = new DisparoSimple();
    private PoolDeBalas pool;

    private int recarga = 0;

    // Power-up de disparo triple
    private int tiempoEspecial = 0;

    // Sistema de vidas
    private int vidas = 3;
    private int tiempoInvulnerable = 0;

    // Escudo
    private boolean escudoActivo = false;
    private int tiempoEscudo = 0;

    // Mensajes
    private int tiempoMensajeInicio = 120;
    private int tiempoMensajeEscudo = 0;

    private boolean gameOver = false;

    // Imagen original de la nave
    private GreenfootImage imagenBase;

    // Evolución visual según puntaje
    private int nivelVisualActual = -1;


    public Nave(PoolDeBalas pool)
    {
        this.pool = pool;

        imagenBase = new GreenfootImage(getImage());
        imagenBase.scale(100, 80);

        setImage(new GreenfootImage(imagenBase));
    }


    public void act()
    {
        if (gameOver) {
            return;
        }

        mover();

        // Power-ups
        recolectarPowerUp();
        recolectarEscudo();

        // Temporizadores
        gestionarTemporizadorArma();
        gestionarEscudo();
        gestionarInvulnerabilidad();
        gestionarMensajeEscudo();

        verificarColisionEnemigo();

        if (gameOver) {
            return;
        }

        disparar();

        mostrarVidas();
        mostrarMensajeInicio();

        actualizarAparienciaPorPuntos();
    }


    // =========================
    // MOVIMIENTO
    // =========================

    private void mover()
    {
        if (Greenfoot.isKeyDown("up") && getY() > 10)
        {
            setLocation(getX(), getY() - 4);
        }

        if (Greenfoot.isKeyDown("down")
            && getY() < getWorld().getHeight() - 10)
        {
            setLocation(getX(), getY() + 4);
        }
    }


    // =========================
    // MONSTER - TRIPLE SHOT
    // =========================

    private void recolectarPowerUp()
    {
        Monster m =
            (Monster)getOneIntersectingObject(Monster.class);

        if (m != null)
        {
            estrategia = new DisparoTriple();

            // Aproximadamente 10 segundos
            tiempoEspecial = 600;

            getWorld().removeObject(m);

            getWorld().showText(
                "TRIPLE SHOT!",
                getWorld().getWidth() / 2,
                50
            );
        }
    }


    private void gestionarTemporizadorArma()
    {
        if (tiempoEspecial > 0)
        {
            tiempoEspecial--;

            if (tiempoEspecial == 0)
            {
                estrategia = new DisparoSimple();

                getWorld().showText(
                    "",
                    getWorld().getWidth() / 2,
                    50
                );
            }
        }
    }


    // =========================
    // ESCUDO
    // =========================

    private void recolectarEscudo()
    {
        Escudo escudo =
            (Escudo)getOneIntersectingObject(Escudo.class);

        if (escudo != null)
        {
            escudoActivo = true;

            // Aproximadamente 5 segundos
            tiempoEscudo = 300;

            mostrarHaloEscudo();

            getWorld().removeObject(escudo);

            getWorld().showText(
                "SHIELD!",
                getWorld().getWidth() / 2,
                80
            );
        }
    }


    private void gestionarEscudo()
    {
        if (escudoActivo && tiempoEscudo > 0)
        {
            tiempoEscudo--;

            if (tiempoEscudo == 0)
            {
                escudoActivo = false;

                restaurarImagenNave();

                // Obliga a recuperar el halo correspondiente
                // al puntaje actual
                nivelVisualActual = -1;

                getWorld().showText(
                    "",
                    getWorld().getWidth() / 2,
                    80
                );
            }
        }
    }


    private void mostrarHaloEscudo()
    {
        GreenfootImage imagenConEscudo =
            new GreenfootImage(120, 100);

        imagenConEscudo.setColor(Color.PINK);

        imagenConEscudo.drawOval(
            4,
            4,
            111,
            91
        );

        imagenConEscudo.drawOval(
            7,
            7,
            105,
            85
        );

        imagenConEscudo.drawImage(
            imagenBase,
            10,
            10
        );

        setImage(imagenConEscudo);
    }


    // =========================
    // COLISIONES Y VIDAS
    // =========================

    private void verificarColisionEnemigo()
    {
        Enemigo e =
            (Enemigo)getOneIntersectingObject(Enemigo.class);

        if (e != null)
        {
            double distancia =
                Math.hypot(
                    getX() - e.getX(),
                    getY() - e.getY()
                );

            // Colisión real
            if (distancia < 20)
            {
                // Si tiene escudo, no pierde vida
                if (escudoActivo)
                {
                    escudoActivo = false;
                    tiempoEscudo = 0;

                    restaurarImagenNave();
                    nivelVisualActual = -1;

                    getWorld().removeObject(e);

                    getWorld().showText(
                        "SHIELD USED!",
                        getWorld().getWidth() / 2,
                        80
                    );

                    tiempoMensajeEscudo = 90;

                    return;
                }


                // Si está temporalmente invulnerable
                if (tiempoInvulnerable > 0)
                {
                    return;
                }


                vidas--;

                // Pequeña invulnerabilidad
                tiempoInvulnerable = 90;

                getWorld().removeObject(e);

                mostrarVidas();


                if (vidas <= 0)
                {
                    gameOver = true;

                    getWorld().showText(
                        "YOU LOSE!",
                        getWorld().getWidth() / 2,
                        getWorld().getHeight() / 2
                    );

                    Greenfoot.stop();
                }
            }
        }
    }


    private void gestionarInvulnerabilidad()
    {
        if (tiempoInvulnerable > 0)
        {
            tiempoInvulnerable--;
        }
    }


    // =========================
    // MENSAJE DEL ESCUDO
    // =========================

    private void gestionarMensajeEscudo()
    {
        if (tiempoMensajeEscudo > 0)
        {
            tiempoMensajeEscudo--;

            if (tiempoMensajeEscudo == 0)
            {
                getWorld().showText(
                    "",
                    getWorld().getWidth() / 2,
                    80
                );
            }
        }
    }


    // =========================
    // DISPARO
    // =========================

    private void disparar()
    {
        if (recarga > 0)
        {
            recarga--;
        }

        if (Greenfoot.isKeyDown("space")
            && recarga == 0)
        {
            estrategia.disparar(this, pool);

            recarga = 15;
        }
    }


    // =========================
    // HUD
    // =========================

    private void mostrarVidas()
    {
        getWorld().showText(
            "Lives: " + vidas,
            530,
            20
        );
    }


    private void mostrarMensajeInicio()
    {
        if (tiempoMensajeInicio > 0)
        {
            if (tiempoMensajeInicio == 120)
            {
                getWorld().showText(
                    "LET'S GO!",
                    getWorld().getWidth() / 2,
                    getWorld().getHeight() / 2
                );
            }

            tiempoMensajeInicio--;

            if (tiempoMensajeInicio == 0)
            {
                getWorld().showText(
                    "",
                    getWorld().getWidth() / 2,
                    getWorld().getHeight() / 2
                );
            }
        }
    }


    // =========================
    // EVOLUCIÓN VISUAL
    // =========================

    private void actualizarAparienciaPorPuntos()
    {
    // Si el escudo está activo, tiene prioridad visual
    if (escudoActivo)
    {
        return;
    }

    int puntos =
        GameManager
            .getInstancia()
            .getPuntos();

    int nuevoNivelVisual;


    if (puntos >= 2000)
    {
        nuevoNivelVisual = 10;
    }
    else if (puntos >= 1800)
    {
        nuevoNivelVisual = 9;
    }
    else if (puntos >= 1600)
    {
        nuevoNivelVisual = 8;
    }
    else if (puntos >= 1400)
    {
        nuevoNivelVisual = 7;
    }
    else if (puntos >= 1200)
    {
        nuevoNivelVisual = 6;
    }
    else if (puntos >= 1000)
    {
        nuevoNivelVisual = 5;
    }
    else if (puntos >= 800)
    {
        nuevoNivelVisual = 4;
    }
    else if (puntos >= 600)
    {
        nuevoNivelVisual = 3;
    }
    else if (puntos >= 400)
    {
        nuevoNivelVisual = 2;
    }
    else if (puntos >= 200)
    {
        nuevoNivelVisual = 1;
    }
    else
    {
        nuevoNivelVisual = 0;
    }


    // Si sigue en el mismo rango, no redibujamos
    if (nuevoNivelVisual == nivelVisualActual)
    {
        return;
    }

    nivelVisualActual = nuevoNivelVisual;


    switch (nuevoNivelVisual)
    {
        case 0:
            restaurarImagenNave();
            break;

        case 1:
            mostrarBrilloPuntaje(Color.BLUE);
            break;

        case 2:
            mostrarBrilloPuntaje(Color.CYAN);
            break;

        case 3:
            mostrarBrilloPuntaje(Color.GREEN);
            break;

        case 4:
            mostrarBrilloPuntaje(Color.MAGENTA);
            break;

        case 5:
            mostrarBrilloPuntaje(
                new Color(170, 0, 255)
            );
            break;

        case 6:
            mostrarBrilloPuntaje(Color.YELLOW);
            break;

        case 7:
            mostrarBrilloPuntaje(
                new Color(255, 140, 0)
            );
            break;

        case 8:
            mostrarBrilloPuntaje(Color.WHITE);
            break;

        case 9:
            mostrarBrilloPuntaje(Color.RED);
            break;

        case 10:
            mostrarBrilloPuntaje(
                new Color(255, 215, 0)
            );
            break;
        }
    }
    private void mostrarBrilloPuntaje(Color color)
    {
        GreenfootImage imagenConBrillo =
            new GreenfootImage(120, 100);

        imagenConBrillo.setColor(color);

        imagenConBrillo.drawOval(
            4,
            4,
            111,
            91
        );

        imagenConBrillo.drawOval(
            7,
            7,
            105,
            85
        );

        imagenConBrillo.drawImage(
            imagenBase,
            10,
            10
        );

        setImage(imagenConBrillo);
    }


    private void restaurarImagenNave()
    {
        setImage(
            new GreenfootImage(imagenBase)
        );
    }
}
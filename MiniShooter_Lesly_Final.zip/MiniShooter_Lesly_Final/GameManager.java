import java.util.ArrayList;
import java.util.List;

public class GameManager {
    private static GameManager instancia;
    private int puntos = 0;
    private List<Observador> observadores = new ArrayList<>();

    private GameManager() {}

    public static GameManager getInstancia() {
        if (instancia == null) {
            instancia = new GameManager();
        }
        return instancia;
    }

    public void reiniciarPuntos() {
        this.puntos = 0;
        notificarObservadores();
    }

    public void sumarPuntos(int cantidad) {
        this.puntos += cantidad;
        notificarObservadores();
    }

    public int getPuntos() {
        return puntos;
    }

    public void agregarObservador(Observador obs) {
        if (!observadores.contains(obs)) {
            observadores.add(obs);
        }
    }

    private void notificarObservadores() {
        for (Observador obs : observadores) {
            obs.notificar(puntos);
        }
    }
}
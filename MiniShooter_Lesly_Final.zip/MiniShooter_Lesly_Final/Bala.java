import greenfoot.*;

public class Bala extends Actor
{
    private PoolDeBalas pool;

    private int velocidad = 8;

    private Color colorBala = Color.YELLOW;


    public Bala(PoolDeBalas pool)
    {
        this.pool = pool;
    }


    @Override
    protected void addedToWorld(World world)
    {
        crearImagen();
    }


    private void crearImagen()
    {
        GreenfootImage img =
            new GreenfootImage(15, 6);

        img.setColor(colorBala);

        img.fillRect(
            0,
            0,
            15,
            6
        );

        setImage(img);
    }


    public void cambiarColor(Color nuevoColor)
    {
        colorBala = nuevoColor;

        if (getWorld() != null)
        {
            crearImagen();
        }
    }


    public void act()
    {
        if (getWorld() != null)
        {
            move(velocidad);

            verificarImpacto();


            if (
                getWorld() != null
                &&
                (
                    isAtEdge()
                    ||
                    getX()
                    >= getWorld().getWidth() - 10
                )
            )
            {
                desactivar();
            }
        }
    }


    private void verificarImpacto()
    {
        Enemigo e =
            (Enemigo)getOneIntersectingObject(
                Enemigo.class
            );

        if (e != null)
        {
            e.destruir();

            desactivar();
        }
    }


    private void desactivar()
    {
        if (getWorld() != null)
        {
            getWorld().removeObject(this);

            if (pool != null)
            {
                pool.devolverBala(this);
            }
        }
    }
}
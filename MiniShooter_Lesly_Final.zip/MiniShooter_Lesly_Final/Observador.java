public interface Observador {
    void notificar(int puntos);
}
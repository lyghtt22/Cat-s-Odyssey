public interface Estado {
    Estado actuar(Enemigo enemigo);
}
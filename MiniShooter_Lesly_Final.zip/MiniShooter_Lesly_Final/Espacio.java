import greenfoot.*;

public class Espacio extends World
{
    private PoolDeBalas pool;

    private int contadorMonster = 0;

    // 7 segundos aprox.
    private final int TIEMPO_SPAWN_MONSTER = 420;


    private int contadorEscudo = 0;

    // 12 segundos aprox.
    private final int TIEMPO_SPAWN_ESCUDO = 720;


    public Espacio()
    {
        super(600, 400, 1);

        GameManager
            .getInstancia()
            .reiniciarPuntos();

        pool = new PoolDeBalas(10);

        addObject(
            new Nave(pool),
            80,
            200
        );

        addObject(
            new Marcador(),
            100,
            30
        );
    }


    public void act()
    {
        generarEnemigos();

        generarMonsterCada7Segundos();

        generarEscudo();
    }


    private void generarEnemigos()
    {
        if (Greenfoot.getRandomNumber(100) < 2)
        {
            addObject(
                new Enemigo(),
                590,
                Greenfoot.getRandomNumber(360) + 20
            );
        }
    }


    private void generarMonsterCada7Segundos()
    {
        contadorMonster++;

        if (contadorMonster >= TIEMPO_SPAWN_MONSTER)
        {
            int yAleatorio =
                Greenfoot.getRandomNumber(340) + 30;

            addObject(
                new Monster(),
                590,
                yAleatorio
            );

            contadorMonster = 0;
        }
    }


    private void generarEscudo()
    {
        contadorEscudo++;

        if (contadorEscudo >= TIEMPO_SPAWN_ESCUDO)
        {
            int yAleatorio =
                Greenfoot.getRandomNumber(340) + 30;

            addObject(
                new Escudo(),
                590,
                yAleatorio
            );

            contadorEscudo = 0;
        }
    }
}
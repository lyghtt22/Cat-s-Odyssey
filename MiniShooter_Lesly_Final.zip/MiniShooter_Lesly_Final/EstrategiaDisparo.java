import greenfoot.*;

public interface EstrategiaDisparo {
    void disparar(Actor tirador, PoolDeBalas pool);
}
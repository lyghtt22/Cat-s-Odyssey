import greenfoot.*;

public class Enemigo extends Actor {
    private Estado estado = new Avanzar(); // Inicia directo en movimiento rectilíneo

    public Enemigo() {
        GreenfootImage img = getImage();
        img.scale(50, 50);
        setImage(img);
    }

    public void act() {
        // Ejecuta el movimiento rectilíneo
        estado = estado.actuar(this);
        
        // Se elimina limpiamente al llegar al borde izquierdo
        if (isAtEdge() || getX() <= 10) {
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
        }
    }

    public void destruir() {
        GameManager.getInstancia().sumarPuntos(10);
        if (getWorld() != null) {
            getWorld().removeObject(this);
        }
    }
}
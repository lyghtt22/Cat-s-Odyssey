import greenfoot.*;
import java.util.ArrayList;
import java.util.List;

public class PoolDeBalas {
    private List<Bala> disponibles = new ArrayList<>();

    public PoolDeBalas(int cantidadInicial) {
        for (int i = 0; i < cantidadInicial; i++) {
            disponibles.add(new Bala(this));
        }
    }

    public Bala getBala() {
        if (!disponibles.isEmpty()) {
            return disponibles.remove(0);
        }
        return new Bala(this);
    }

    public void devolverBala(Bala bala) {
        if (!disponibles.contains(bala)) {
            disponibles.add(bala);
        }
    }
}
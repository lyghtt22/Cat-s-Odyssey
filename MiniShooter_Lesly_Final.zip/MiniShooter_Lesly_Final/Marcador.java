import greenfoot.*;

public class Marcador extends Actor implements Observador {
    private int puntos = 0;

    public Marcador() {
        GameManager.getInstancia().agregarObservador(this);
        actualizarImagen();
    }

    @Override
    public void notificar(int puntos) {
        this.puntos = puntos;
        actualizarImagen();
    }

    private void actualizarImagen() {
        setImage(new GreenfootImage("SCORE: " + puntos, 24, Color.WHITE, new Color(0, 0, 0, 0)));
    }
}
import greenfoot.*;

public class Escudo extends Actor
{
    public Escudo()
    {
        setImage("escudo rosado.png");

        GreenfootImage img = getImage();

        img.scale(40, 40);

        setImage(img);
    }


    public void act()
    {
        // El escudo se mueve hacia la nave
        setLocation(
            getX() - 2,
            getY()
        );


        // Si sale de pantalla se elimina
        if (getX() <= 1)
        {
            getWorld().removeObject(this);
        }
    }
}
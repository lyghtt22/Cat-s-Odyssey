import greenfoot.*;

public class Monster extends Actor {
    public Monster() {
        // Obtenemos la imagen asignada
        GreenfootImage img = getImage();
        // La redimensionamos a un tamaño pequeño (ejemplo: 25x40 píxeles)
        img.scale(75, 75); 
        setImage(img);
    }

    public void act() {
        if (getWorld() != null) {
            setLocation(getX() - 2, getY());
            if (getX() < 0) {
                getWorld().removeObject(this);
            }
        }
    }
}
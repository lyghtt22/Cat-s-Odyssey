import greenfoot.*;

public class DisparoSimple
    implements EstrategiaDisparo
{
    public void disparar(
        Actor tirador,
        PoolDeBalas pool
    )
    {
        World mundo =
            tirador.getWorld();


        if (mundo != null && pool != null)
        {
            Bala b =
                pool.getBala();


            if (b != null)
            {
                // Disparo normal amarillo
                b.cambiarColor(
                    Color.YELLOW
                );

                mundo.addObject(
                    b,
                    tirador.getX() + 20,
                    tirador.getY()
                );

                b.setRotation(0);
            }
        }
    }
}
import greenfoot.*;

public class DisparoTriple
    implements EstrategiaDisparo
{
    public void disparar(
        Actor tirador,
        PoolDeBalas pool
    )
    {
        World mundo =
            tirador.getWorld();


        if (mundo != null && pool != null)
        {
            int x =
                tirador.getX() + 20;

            int y =
                tirador.getY();


            // Bala superior
            Bala b1 =
                pool.getBala();

            if (b1 != null)
            {
                b1.cambiarColor(
                    Color.MAGENTA
                );

                mundo.addObject(
                    b1,
                    x,
                    y
                );

                b1.setRotation(-15);
            }


            // Bala central
            Bala b2 =
                pool.getBala();

            if (b2 != null)
            {
                b2.cambiarColor(
                    Color.MAGENTA
                );

                mundo.addObject(
                    b2,
                    x,
                    y
                );

                b2.setRotation(0);
            }


            // Bala inferior
            Bala b3 =
                pool.getBala();

            if (b3 != null)
            {
                b3.cambiarColor(
                    Color.MAGENTA
                );

                mundo.addObject(
                    b3,
                    x,
                    y
                );

                b3.setRotation(15);
            }
        }
    }
}
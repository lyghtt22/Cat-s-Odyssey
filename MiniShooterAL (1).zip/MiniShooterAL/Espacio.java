import greenfoot.*;

public class Espacio extends World {
    private PoolDeBalas pool;
    private int contadorMonster = 0;
    // 7 segundos * 60 actos/segundo = 420 ciclos
    private final int TIEMPO_SPAWN_MONSTER = 420; 

    public Espacio() {    
        super(600, 400, 1);
        
        GameManager.getInstancia().reiniciarPuntos();
        pool = new PoolDeBalas(10);

        addObject(new Nave(pool), 80, 200);
        addObject(new Marcador(), 100, 30);
    }

    public void act() {
        generarEnemigos();
        generarMonsterCada7Segundos();
    }

    private void generarEnemigos() {
        // Mantiene la generación aleatoria de asteroides
        if (Greenfoot.getRandomNumber(100) < 2) {
            addObject(new Enemigo(), 590, Greenfoot.getRandomNumber(360) + 20);
        }
    }

    private void generarMonsterCada7Segundos() {
        contadorMonster++;
        if (contadorMonster >= TIEMPO_SPAWN_MONSTER) {
            // Aparece en una posición vertical aleatoria a la derecha de la pantalla
            int yAleatorio = Greenfoot.getRandomNumber(340) + 30;
            addObject(new Monster(), 590, yAleatorio);
            
            // Reiniciamos el contador para los próximos 7 segundos
            contadorMonster = 0; 
        }
    }
}
import greenfoot.*;

public class DisparoSimple implements EstrategiaDisparo {
    
    public void disparar(Actor tirador, PoolDeBalas pool) {
        World mundo = tirador.getWorld();
        if (mundo != null && pool != null) {
            Bala b = pool.getBala();
            if (b != null) {
                mundo.addObject(b, tirador.getX() + 20, tirador.getY());
                b.setRotation(0);
            }
        }
    }
}
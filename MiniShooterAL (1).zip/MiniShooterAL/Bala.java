import greenfoot.*;

public class Bala extends Actor {
    private PoolDeBalas pool;
    private int velocidad = 8;

    public Bala(PoolDeBalas pool) {
        this.pool = pool;
    }

    // Se ejecuta SIEMPRE que la bala entra al mundo, garantizando el rayo amarillo
    @Override
    protected void addedToWorld(World world) {
        crearImagenAmarilla();
    }

    private void crearImagenAmarilla() {
        GreenfootImage img = new GreenfootImage(15, 6);
        img.setColor(Color.YELLOW);
        img.fillRect(0, 0, 15, 6);
        setImage(img);
    }

    public void act() {
        if (getWorld() != null) {
            // move() hace que avance respetando la rotación (para la bala triple)
            move(velocidad); 
            verificarImpacto();

            if (getWorld() != null && (isAtEdge() || getX() >= getWorld().getWidth() - 10)) {
                desactivar();
            }
        }
    }

    private void verificarImpacto() {
        Enemigo e = (Enemigo) getOneIntersectingObject(Enemigo.class);
        if (e != null) {
            e.destruir();
            desactivar();
        }
    }

    private void desactivar() {
        if (getWorld() != null) {
            getWorld().removeObject(this);
            if (pool != null) {
                pool.devolverBala(this);
            }
        }
    }
}
import greenfoot.*;

public class DisparoTriple implements EstrategiaDisparo {
    
    public void disparar(Actor tirador, PoolDeBalas pool) {
        World mundo = tirador.getWorld();
        if (mundo != null && pool != null) {
            int x = tirador.getX() + 20;
            int y = tirador.getY();

            // Bala hacia arriba (en abanico)
            Bala b1 = pool.getBala();
            if (b1 != null) {
                mundo.addObject(b1, x, y);
                b1.setRotation(-15);
            }

            // Bala recta (al centro)
            Bala b2 = pool.getBala();
            if (b2 != null) {
                mundo.addObject(b2, x, y);
                b2.setRotation(0);
            }

            // Bala hacia abajo (en abanico)
            Bala b3 = pool.getBala();
            if (b3 != null) {
                mundo.addObject(b3, x, y);
                b3.setRotation(15);
            }
        }
    }
}
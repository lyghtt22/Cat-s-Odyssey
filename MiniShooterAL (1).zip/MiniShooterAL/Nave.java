import greenfoot.*;

public class Nave extends Actor {
    private EstrategiaDisparo estrategia = new DisparoSimple();
    private PoolDeBalas pool;
    private int recarga = 0;
    private int tiempoEspecial = 0; // Temporizador para la Monster (10 segundos)

    public Nave(PoolDeBalas pool) {
        this.pool = pool;
        
        // Ajuste de tamaño proporcional
        GreenfootImage img = getImage();
        img.scale(100, 80); // 40px de ancho x 30px de alto
        setImage(img);
    }

    public void act() {
        mover();
        recolectarPowerUp();
        gestionarTemporizadorArma();
        verificarColisionEnemigo();
        disparar();
    }

    private void mover() {
        if (Greenfoot.isKeyDown("up") && getY() > 10) {
            setLocation(getX(), getY() - 4);
        }
        if (Greenfoot.isKeyDown("down") && getY() < getWorld().getHeight() - 10) {
            setLocation(getX(), getY() + 4);
        }
    }

    // Activa disparo triple por 10 segundos al tocar la Monster
    private void recolectarPowerUp() {
        Monster m = (Monster) getOneIntersectingObject(Monster.class);
        if (m != null) {
            estrategia = new DisparoTriple();
            tiempoEspecial = 600; // 600 frames = 10 segundos
            getWorld().removeObject(m);
        }
    }

    // Regresa al disparo simple tras agotarse los 10 segundos
    private void gestionarTemporizadorArma() {
        if (tiempoEspecial > 0) {
            tiempoEspecial--;
            if (tiempoEspecial == 0) {
                estrategia = new DisparoSimple();
            }
        }
    }

    // Colisión precisa basada en distancia (evita bordes transparentes)
    private void verificarColisionEnemigo() {
        Enemigo e = (Enemigo) getOneIntersectingObject(Enemigo.class);
        if (e != null) {
            double distancia = Math.hypot(getX() - e.getX(), getY() - e.getY());
            
            // Si los centros están a menos de 20px, hay choque real
            if (distancia < 20) { 
                Greenfoot.setWorld(new Espacio());
            }
        }
    }

    private void disparar() {
        if (recarga > 0) recarga--;
        if (Greenfoot.isKeyDown("space") && recarga == 0) {
            estrategia.disparar(this, pool);
            recarga = 15;
        }
    }
}